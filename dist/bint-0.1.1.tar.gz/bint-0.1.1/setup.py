# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['bint']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'bint',
    'version': '0.1.1',
    'description': 'Binary INTteger representation toolkit',
    'long_description': None,
    'author': 'hellman',
    'author_email': 'hellman@affine.group',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.5,<4.0',
}


setup(**setup_kwargs)
